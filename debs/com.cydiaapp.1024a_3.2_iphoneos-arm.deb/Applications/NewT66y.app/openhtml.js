jqueryData

function getHtmlData(url){
	var get = $.get(url, function(data){
        window.webkit.messageHandlers.app.postMessage(htmlConvert(data));
    });
}

function htmlConvert(data){
	data = data.replace(/<(img|input) src='(.*?)'/ig, "<$1 src='' width='30' alt='$2'");
	data = data.replace(/&src='\+encodeURIComponent\(this.src\)/ig, "&src='+encodeURIComponent(this.alt)");
    return data;
}

$(document).ready(function(){
	$(document).ajaxError(function(event, jqXHR, options, errorMsg){
		window.webkit.messageHandlers.app.postMessage(errorMsg);
    });
});

